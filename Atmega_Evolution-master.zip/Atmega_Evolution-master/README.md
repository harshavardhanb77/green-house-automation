# Atmega_Evolution
# **OVERVIEW AND THE FUNCTIONINNG OF THE HOUSE**
arduino code runs the sensors
tempertaure and humidity sensor (dht11) displays the temperature and the humidity of the house
soil moisture sensor senses the moisture content in the soil and it is inturn contected to the water pump which turns ON when the moisture content in the soil decreases


# **WORKING AND THE ANALYSIS OF THE DATA**
carbon dioxide sensor (mq-4 )senses the carbon dioxide concentration in the house and displays the output in parts per million
air quality sensor(mq-135) senses the purity of the air and presence of the harmful gases in the house
all these sensors are  controlled by arduino and NODEmcu WI-FI module
the data is analysed and recorded in the webpage 

# **CONTROL SYSTEM OF THE CIRCUIT**
the environment of the house can be controlled by the exhaust fans and high wattage bulbs to cool or heat the house and vice versa
Node mcu basically establishes the connection between the webpage and the h


